import sqlite3
db = sqlite3.connect("AppointmentTable2.db")
cur = db.cursor()
# A very simple Bottle Hello World app for you to get started with...
from bottle import default_app, route, template, post, get

@route('/')
def SGH():
    return template('log-in.html')

@route('/login')
def login():
    return template('retusr.html')

@route('/newuser/signup')
def signup():
    return template('newusr.html')

@post('/userselection')
def pick():
    return template('options.html',c = cur)

@route('/schedule')
def shed():
    return template('schedule.html',c = cur)

@post('/confirmationpage')
def choice():
    return template('confirmationpage.html')

@route('/reschedule')
def reshed():
    return template('reschedule.html')

@post('/reshedpage')
def reconf():
    return template('newappconf.html')

@route('/cancel')
def cancel():
    return template('cancel.html')

@post('/canappconf')
def canconf():
    return template('canconf.html')

application = default_app()
