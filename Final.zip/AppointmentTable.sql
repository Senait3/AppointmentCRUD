Drop table if exists appoints;

Create table appoints (
  Id  INTEGER Primary key,
  Doctor varchar(50),
  Specialty varchar(50),
  Center VARCHAR(50),
  Scheduled VARCHAR(50)
); 

insert into appoints values('null', 'Dr.Joy' , 'Dermatology', 'Center for Dermarology', 'No Appointment Set');
insert into appoints values('null', 'Dr.Smith' , 'Cardiology', 'Center for Cardiac Care','No Appointment Set');
insert into appoints values('null', 'Dr.Adams' , 'Pediatrics', 'Center for Family Medicine','No Appointment Set');
insert into appoints values('null', 'Dr.Williams' , 'Gynecology','Center for OB/GYN','No Appointment Set');
insert into appoints values('null', 'Dr.Davis' , 'Orthopedics', 'Center for Orthapedic Care','No Appointment Set');
insert into appoints values('null', 'Dr.Miller' , 'General Surgery','Center for General Surgery','No Appointment Set');

Select * from appoints;  




